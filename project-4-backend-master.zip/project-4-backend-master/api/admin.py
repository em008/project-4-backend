from django.contrib import admin
from api.models import Subject, Topic

# Register your models here.
admin.site.register(Subject)
admin.site.register(Topic)


